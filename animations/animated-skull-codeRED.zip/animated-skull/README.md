# Animated Skull

A Pen created on CodePen.io. Original URL: [https://codepen.io/WarrioR56/pen/BaPmPqv](https://codepen.io/WarrioR56/pen/BaPmPqv).

Animated skull with Threejs for Creative Coding CLub - It's alive