# Procedurally generated minimal environment

A Pen created on CodePen.io. Original URL: [https://codepen.io/marctannous/pen/RNGjmz](https://codepen.io/marctannous/pen/RNGjmz).

Inspired from www.makemepulse.com, want to recreate the breathing effect.