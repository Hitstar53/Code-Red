# Text Shadow

A Pen created on CodePen.io. Original URL: [https://codepen.io/gabriele_997/pen/wvqPKKE](https://codepen.io/gabriele_997/pen/wvqPKKE).

