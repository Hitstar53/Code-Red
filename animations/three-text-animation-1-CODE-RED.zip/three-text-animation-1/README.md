# THREE Text Animation #1

A Pen created on CodePen.io. Original URL: [https://codepen.io/zadvorsky/pen/GZmKYX](https://codepen.io/zadvorsky/pen/GZmKYX).

First in a series of experiments with THREE.js and type.